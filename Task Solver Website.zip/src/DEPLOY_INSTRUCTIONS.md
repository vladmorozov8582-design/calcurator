# 🚀 ИНСТРУКЦИЯ ПО ДЕПЛОЮ НА VERCEL

## ШАГ 1: Создать аккаунт на GitHub (2 минуты)

1. Перейдите на https://github.com
2. Нажмите **Sign up** (Регистрация)
3. Заполните:
   - Email (ваша почта)
   - Пароль
   - Username (придумайте имя, например: calculator-ru)
4. Подтвердите email
5. ✅ Готово!

---

## ШАГ 2: Создать репозиторий (1 минута)

1. На главной странице GitHub нажмите **"+"** → **"New repository"**
2. Заполните:
   - **Repository name**: `calculator-solver` (или любое имя)
   - **Description**: "AI задач решатель с калькулятором"
   - ✅ Выберите **Public** (публичный)
   - ❌ НЕ добавляйте README, .gitignore, license (у нас уже есть)
3. Нажмите **Create repository**
4. ✅ Готово! Репозиторий создан.

---

## ШАГ 3: Загрузить файлы проекта (3 минуты)

### Вариант А: Через веб-интерфейс (проще)

1. На странице вашего репозитория нажмите **"uploading an existing file"**
2. Перетащите ВСЕ файлы проекта:
   - 📁 Папку `components` (всю целиком)
   - 📁 Папку `supabase` (всю целиком)
   - 📁 Папку `styles` (всю целиком)
   - 📁 Папку `utils` (всю целиком)
   - 📄 Все файлы в корне: App.tsx, package.json, vercel.json, и т.д.
3. Внизу страницы нажмите **Commit changes**
4. ✅ Готово!

### Вариант Б: Через Git CLI (для опытных)

Если вы знакомы с командной строкой:

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/ваш-username/calculator-solver.git
git push -u origin main
```

---

## ШАГ 4: Создать аккаунт на Vercel (1 минута)

1. Перейдите на https://vercel.com
2. Нажмите **Sign Up**
3. Выберите **Continue with GitHub**
4. Разрешите доступ Vercel к вашему GitHub
5. ✅ Готово!

---

## ШАГ 5: Задеплоить проект (2 минуты)

1. В Vercel Dashboard нажмите **"Add New..."** → **"Project"**
2. Найдите репозиторий `calculator-solver`
3. Нажмите **Import**
4. В настройках:
   - **Framework Preset**: Vite (должно определиться автоматически)
   - **Root Directory**: `./` (оставьте по умолчанию)
   - **Build Command**: `npm run build` (должно быть автоматически)
   - **Output Directory**: `dist` (должно быть автоматически)
5. Пролистайте до **Environment Variables**
6. Добавьте переменные:
   ```
   VITE_SUPABASE_URL = [ваш Supabase URL]
   VITE_SUPABASE_ANON_KEY = [ваш Supabase Anon Key]
   ```
7. Нажмите **Deploy**
8. Подождите 1-2 минуты
9. ✅ Готово! Сайт задеплоен!

---

## ШАГ 6: Получить ссылку на сайт

1. После деплоя Vercel покажет: **"Congratulations!"**
2. Вы увидите ссылку типа: `https://calculator-solver.vercel.app`
3. Нажмите на неё - сайт работает!
4. ✅ Готово!

---

## ШАГ 7: Подключить домен calculator.ru (5-10 минут)

1. В Vercel перейдите в **Settings** → **Domains**
2. Введите `calculator.ru`
3. Нажмите **Add**
4. Vercel покажет инструкции с DNS записями

5. Перейдите в панель REG.RU:
   - Найдите домен `calculator.ru`
   - Перейдите в управление DNS
   - Измените записи:
     - **A-запись**: `@` → `76.76.21.21`
     - **CNAME**: `www` → `cname.vercel-dns.com.`
   
6. Сохраните изменения
7. Подождите 30 минут - 24 часа (обычно 1-2 часа)
8. ✅ Готово! Сайт будет доступен на calculator.ru

---

## ШАГ 8: Задеплоить Edge Function в Supabase (5 минут)

### На Windows:

1. Установите Supabase CLI:
   - Скачайте: https://github.com/supabase/cli/releases
   - Или через npm: `npm install -g supabase`

2. Откройте CMD (Командная строка)

3. Залогиньтесь:
   ```bash
   supabase login
   ```

4. Найдите ваш Project ID:
   - Откройте https://supabase.com/dashboard
   - Выберите ваш проект
   - В URL скопируйте ID (после `/project/`)
   - Например: `https://supabase.com/dashboard/project/abcdefgh` → ID = `abcdefgh`

5. Задеплойте функцию:
   ```bash
   cd путь/к/вашему/проекту
   supabase functions deploy server --project-ref ваш-project-id
   ```

6. После деплоя добавьте в Supabase переменные:
   - Откройте Supabase Dashboard
   - Перейдите в **Settings** → **Edge Functions** → **Secrets**
   - Добавьте переменную:
     ```
     OPENROUTER_API_KEY = sk-or-v1-ваш-ключ
     ```

7. ✅ Готово!

---

## ❓ ГДЕ ВЗЯТЬ API КЛЮЧИ?

### Supabase:
1. Откройте https://supabase.com/dashboard
2. Выберите ваш проект
3. Перейдите в **Settings** → **API**
4. Скопируйте:
   - **Project URL** → это ваш `VITE_SUPABASE_URL`
   - **anon/public key** → это ваш `VITE_SUPABASE_ANON_KEY`

### OpenRouter (для решения задач):
1. Откройте https://openrouter.ai/keys
2. Зарегистрируйтесь
3. Создайте новый ключ
4. Скопируйте (начинается с `sk-or-v1-...`)

---

## ✅ CHECKLIST - ВСЕ ЛИ ГОТОВО?

- [ ] GitHub аккаунт создан
- [ ] Репозиторий создан
- [ ] Файлы загружены в репозиторий
- [ ] Vercel аккаунт создан
- [ ] Проект задеплоен на Vercel
- [ ] Environment Variables добавлены в Vercel
- [ ] Сайт открывается по ссылке `*.vercel.app`
- [ ] Edge Function задеплоена в Supabase
- [ ] OPENROUTER_API_KEY добавлен в Supabase
- [ ] Домен calculator.ru настроен (опционально)

---

## 🆘 ПОМОЩЬ

Если что-то не работает:
1. Проверьте логи в Vercel Dashboard
2. Проверьте логи в Supabase → Edge Functions
3. Откройте консоль браузера (F12) и посмотрите ошибки

---

## 🎉 ГОТОВО!

Ваш сайт работает! Теперь пользователи могут:
- ✅ Использовать научный калькулятор
- ✅ Загружать фото задач
- ✅ Получать универсальный Python-код для решения
- ✅ Вводить свои данные через `input()`

**Успехов! 🚀**
